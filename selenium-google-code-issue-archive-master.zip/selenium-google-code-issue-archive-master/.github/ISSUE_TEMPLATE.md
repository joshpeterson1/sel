## DO NOT LOG AN ISSUE HERE. THIS IS AN ARCHIVE ONLY

Log new selenium issues here:

https://github.com/seleniumhq/selenium/issues/new


This issue will be closed immediately without any comment if you log it here. You will also receive animosity from project members for your willful disregard of this notice.
